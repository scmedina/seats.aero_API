namespace FlightRecordLowViewer
{
    public partial class MainView : Form
    {
        public MainView()
        {
            InitializeComponent();
        }
    }
}