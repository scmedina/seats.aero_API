﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SeatsAeroLibrary.Helpers
{
    public enum LocationType
    {
        Airport = 0,
        Region = 1
    }
}
