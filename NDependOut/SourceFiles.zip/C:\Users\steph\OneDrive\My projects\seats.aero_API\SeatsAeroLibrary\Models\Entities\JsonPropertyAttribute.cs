﻿namespace SeatsAeroLibrary.Models
{
    internal class JsonPropertyAttribute : Attribute
    {
    }
}